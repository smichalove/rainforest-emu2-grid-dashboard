# Integrate SolarEdge & Chillicon Dual-System Analysis

## Background & New Context
You have a dual solar setup:
1.  **SolarEdge System** (Has API, 300 requests/day limit)
2.  **Chillicon System** (No API)
3.  **Rainforest EMU-2** (Measures Net Grid Import/Export)

**Goal:** Estimate the percentage of generation provided by SolarEdge vs Chillicon, add this to the 30-minute Gemini analysis, and potentially render a pie chart on the dashboard. We only want to poll the API when there is actual generation.

## ⚠️ Mathematical Constraints (Resolved)

Since the SolarEdge Consumption CTs are inaccurate and blind to the Chillicon system, we **cannot calculate an exact percentage** of total generation. We only have two reliable numbers:
1.  **Accurate Net Grid** (from EMU-2)
2.  **SolarEdge Generation** (from SolarEdge API)

**Final Strategy for Unknowns:**
Instead of trying to force a mathematically impossible calculation, we will:
1.  **Visualize the Raw Data:** Plot the `SolarEdge PV` generation as a separate positive line (or filled area) on the Matplotlib chart, layered against your existing `Net Grid` line. This will give you a powerful visual intuition of when SolarEdge is carrying the load vs when Chillicon is doing the heavy lifting.
2.  **Let Gemini Infer:** We will pass both the `Net Grid` and `SolarEdge PV` data into Gemini. We will instruct Gemini that there is a second (Chillicon) system, and ask it to analyze trends (e.g., "SolarEdge produced 15kWh today, but you exported 20kWh, meaning Chillicon is performing exceptionally well").

## Polling Strategy & Rate Limits

To conserve the 300 requests/day limit, we will align the SolarEdge API calls with the **30-minute Gemini Summary trigger**. 

**Smart Polling Logic:**
1.  **Start Trigger:** We will occasionally check the API after sunrise. The official polling "event" begins the moment the API reports `PV > 0` (i.e., SolarEdge has started production).
2.  **End Trigger:** The polling event will automatically terminate at **sunset**.
3.  Fetching data every 30 minutes during this active generation window results in ~20-25 API calls per day, keeping us extremely safe from the 300 limit!

## Proposed Visuals & Gemini Integration

### Dashboard UI Update
*   **X-Axis Bar Chart Overlay:** Instead of a pie chart, we will use a secondary Y-axis to plot a translucent bar chart directly along the bottom of the main X-axis timeline. This "volume-style" chart will display the SolarEdge 30-minute generation blocks natively alongside the high-resolution Net Grid data.

### Gemini Integration
*   Pass the SolarEdge 30-minute energy yield into `gemini_prompt.txt`. 
*   Ask Gemini to analyze the SolarEdge yield compared to the Net Grid usage to infer insights about the Chillicon system's performance.

## Status
All architectural questions have been resolved and the plan is approved for execution. We will include a bar chart to visualize the SolarEdge generation for the 30-minute periods.
