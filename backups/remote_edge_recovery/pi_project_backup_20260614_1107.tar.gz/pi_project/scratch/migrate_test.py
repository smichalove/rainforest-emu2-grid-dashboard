import os
import time
import datetime
import statistics
import sys
from typing import List, Tuple

# Add repository root to python path to load modules correctly
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dashboard_modules import db, io, telemetry

def main():
    script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    csv_path = os.path.join(script_dir, "grid_history.csv")
    db_path = os.path.join(script_dir, "scratch", "grid_history_test.db")
    
    if not os.path.exists(csv_path):
        print(f"Error: grid_history.csv not found at: {csv_path}")
        return

    if os.path.exists(db_path):
        os.remove(db_path)

    print("==========================================================")
    # 1. Baseline measurements from CSV
    print("Step 1: Reading and parsing CSV baseline metrics...")
    t0 = time.time()
    csv_rows = io.read_clean_csv(csv_path)
    csv_read_time = time.time() - t0
    
    csv_count = len(csv_rows)
    csv_vals = []
    for row in csv_rows:
        if len(row) == 2:
            try:
                csv_vals.append(float(row[1]))
            except ValueError:
                pass
                
    csv_mean = statistics.mean(csv_vals) if csv_vals else 0.0
    csv_std = statistics.stdev(csv_vals) if len(csv_vals) > 1 else 0.0
    csv_sum = sum(csv_vals)
    print(f"CSV Parse: {csv_count} rows in {csv_read_time:.3f}s")
    print(f"CSV Math: Sum={csv_sum:.3f} kW, Mean={csv_mean:.5f} kW, StdDev={csv_std:.5f} kW")

    # 2. Run Migration to SQLite
    print("\nStep 2: Migrating CSV data to test SQLite database...")
    t0 = time.time()
    migrated_count = db.migrate_csv(db_path, csv_path)
    migration_time = time.time() - t0
    print(f"SQLite Migration: Completed in {migration_time:.3f}s. Migrated {migrated_count} records.")

    # 3. DB Parity checks
    print("\nStep 3: Verifying data parity...")
    t0 = time.time()
    db_ts, db_vals = db.query_history(db_path, cutoff_hours=999999) # Load entire window
    db_query_time = time.time() - t0
    
    db_count = len(db_vals)
    db_mean = statistics.mean(db_vals) if db_vals else 0.0
    db_std = statistics.stdev(db_vals) if len(db_vals) > 1 else 0.0
    db_sum = sum(db_vals)
    
    print(f"SQLite Query: Loaded {db_count} records in {db_query_time:.3f}s")
    print(f"SQLite Math: Sum={db_sum:.3f} kW, Mean={db_mean:.5f} kW, StdDev={db_std:.5f} kW")

    # Assert correctness
    count_parity = (csv_count == db_count)
    math_parity = abs(csv_sum - db_sum) < 0.001 and abs(csv_mean - db_mean) < 0.00001
    
    print(f"\nParity Verification:")
    print(f" - Row count match: {'PASSED' if count_parity else 'FAILED'} (CSV: {csv_count}, DB: {db_count})")
    print(f" - Math value match: {'PASSED' if math_parity else 'FAILED'} (Delta Sum: {abs(csv_sum - db_sum):.6f})")

    # 4. Hourly Aggregation Performance Comparison
    print("\nStep 4: Benchmarking hourly aggregation speeds...")
    
    # Python-level hourly aggregates on CSV data (Simulating current stager logic)
    t0 = time.time()
    from collections import defaultdict
    csv_hourly = defaultdict(list)
    for row in csv_rows:
        if len(row) == 2:
            hour_key = row[0][:13] + ":00"
            try:
                csv_hourly[hour_key].append(float(row[1]))
            except ValueError:
                pass
    csv_aggregated = []
    for h in sorted(csv_hourly.keys()):
        vals = csv_hourly[h]
        csv_aggregated.append((h, sum(vals)/len(vals), min(vals), max(vals)))
    duration_csv_agg = time.time() - t0
    
    # SQLite-level hourly aggregates on DB
    t0 = time.time()
    db_aggregated = db.query_hourly_aggregates(
        db_path, 
        start_time="2000-01-01T00:00:00", 
        end_time="2030-01-01T00:00:00"
    )
    duration_db_agg = time.time() - t0

    print(f" - Python-on-CSV Aggregation Time: {duration_csv_agg:.4f}s")
    print(f" - SQLite SQL Aggregation Time: {duration_db_agg:.4f}s")
    speedup = duration_csv_agg / duration_db_agg if duration_db_agg > 0 else 0
    print(f" - SQLite Performance Speedup: {speedup:.1f}x faster!")

    # Verify hourly values match
    print("\nStep 5: Verifying hourly average value parity...")
    mismatches = 0
    csv_dict = {row[0].replace("T", " "): row[1] for row in csv_aggregated}
    
    for row in db_aggregated:
        h_db = row[0]
        val_db = row[1]
        
        # Format key to match CSV layout
        h_csv = h_db.replace("T", " ")
        if h_csv in csv_dict:
            val_csv = csv_dict[h_csv]
            if abs(val_db - val_csv) > 0.001:
                mismatches += 1
                if mismatches <= 5:
                    print(f"   [Mismatch] Hour {h_db}: SQLite Avg={val_db:.4f} kW vs CSV Avg={val_csv:.4f} kW")
        else:
            mismatches += 1
            if mismatches <= 5:
                print(f"   [Mismatch] Hour {h_db}: Present in SQLite, missing in CSV")
                
    if mismatches == 0:
        print(" - Hourly averages parity check: PASSED (100% of hour buckets match exactly).")
    else:
        print(f" - Hourly averages parity check: FAILED ({mismatches} mismatching hours found).")

    print("\nPhase 1 verification completed successfully.")

if __name__ == "__main__":
    main()
