# SQLite Database Rsync Sync Benchmark Report

Generated on: 2026-06-09 13:53:05

This report evaluates the performance and bandwidth characteristics of syncing the SQLite database (`grid_history.db`) from the Raspberry Pi to the Nvidia Jetson Edge server over the local network using `rsync` with compression enabled (`-avz`).

## 1. Database File Metrics
* **Total Rows Populated**: 250,000 (Simulating ~43 days of continuous 15-second demand logs)
* **SQLite Database File Size**: 29.40 MB (30,830,592 bytes)

## 2. Benchmark Sync Results

| Metric | Baseline Sync (Initial Transfer) | Delta Sync (Simulated 5-min update) |
| :--- | :--- | :--- |
| **Duration (seconds)** | 2.206s | 0.754s |
| **Total Sent Over Network** | 2.686 MB (2,816,620 bytes) | 9.25 KB (9,477 bytes) |
| **Efficiency Ratio (Sent vs Size)** | 9.1% | 0.03074% |
| **Effective Net Speed** | 1.22 MB/s | 12.27 KB/s |

## 3. Key Observations & Feasibility Conclusion
1. **Initial Sync Overhead**: The initial compressed sync transfers only **2.69 MB** of raw data due to `rsync`'s zlib compression on repeating patterns, completing in **2.21 seconds**.
2. **Delta Transfer Efficiency**: Adding 20 new rows (simulating a 5-minute data chunk) and resyncing results in transmitting only **9.25 KB** over the network. This proves that `rsync`'s rolling checksum algorithm successfully identifies and transmits *only* the modified/appended blocks of the SQLite binary file, rather than re-transmitting the entire database.
3. **Feasibility**: Syncing the SQLite database file directly is highly efficient and feasible over the Ethernet bridge network, imposing negligible network bandwidth or CPU overhead.
