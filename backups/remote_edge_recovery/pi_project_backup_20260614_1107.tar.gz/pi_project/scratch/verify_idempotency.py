import os
import sqlite3
import sys
import time

# Add repository root to python path to load modules correctly
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dashboard_modules import db

def main():
    script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    csv_path = os.path.join(script_dir, "grid_history.csv")
    db_path = os.path.join(script_dir, "scratch", "grid_history_test.db")
    
    if not os.path.exists(csv_path):
        print(f"Error: grid_history.csv not found at: {csv_path}")
        return

    print("==========================================================")
    print("Phase 2: Database Idempotency & Rebuild Validation")
    print("==========================================================")

    # 1. Clean Rebuild Test
    print("Step 1: Deleting existing test database and running a clean rebuild...")
    if os.path.exists(db_path):
        os.remove(db_path)
        
    t0 = time.time()
    count_first = db.migrate_csv(db_path, csv_path)
    time_first = time.time() - t0
    print(f" -> Rebuild complete: {count_first} rows migrated in {time_first:.3f}s")

    # 2. Duplicate Run Test (Idempotency Check)
    print("\nStep 2: Re-running migration on the populated database (Duplicate Sync)...")
    t0 = time.time()
    count_second = db.migrate_csv(db_path, csv_path)
    time_second = time.time() - t0
    
    # Query row count
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM grid_history")
    final_count = cursor.fetchone()[0]
    conn.close()

    print(f" -> Secondary sync complete: {count_second} new inserts in {time_second:.3f}s")
    print(f" -> Final database row count: {final_count}")

    # Assertions
    idempotent = (count_second == 0) and (final_count == count_first)
    print(f"\nVerification Results:")
    print(f" - Database is idempotent: {'PASSED' if idempotent else 'FAILED'} (Inserts on 2nd run: {count_second})")
    print(f" - Row count maintained: {'PASSED' if final_count == count_first else 'FAILED'} (Expected: {count_first}, Actual: {final_count})")
    
    if idempotent:
        print("\nPhase 2 validation completed successfully.")
    else:
        print("\nPhase 2 validation FAILED.")

if __name__ == "__main__":
    main()
