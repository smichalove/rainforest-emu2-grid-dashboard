import serial
import time
import xml.etree.ElementTree as ET
import sys
from typing import Optional, Tuple

def hex_to_signed_int(hex_str: str, bits: int = 32) -> int:
    """Converts a hexadecimal string representation of a number into a signed integer.

    Args:
        hex_str: The hexadecimal string to convert.
        bits: The bit-width of the target integer.

    Returns:
        The signed integer value.
    """
    val: int = int(hex_str, 16)
    if (val & (1 << (bits - 1))) != 0:
        val = val - (1 << bits)
    return val

def parse_instantaneous_demand(xml_data: str) -> Optional[float]:
    """Parses instantaneous demand XML response from EMU-2.

    Args:
        xml_data: The XML string returned by the device.

    Returns:
        The demand value in kW, or None if parsing fails.
    """
    try:
        root: ET.Element = ET.fromstring(xml_data)
        if root.tag == 'InstantaneousDemand':
            demand_hex: Optional[str] = root.find('Demand').text if root.find('Demand') is not None else None
            multiplier_hex: Optional[str] = root.find('Multiplier').text if root.find('Multiplier') is not None else None
            divisor_hex: Optional[str] = root.find('Divisor').text if root.find('Divisor') is not None else None
            
            if demand_hex and multiplier_hex and divisor_hex:
                demand: int = hex_to_signed_int(demand_hex)
                multiplier: int = int(multiplier_hex, 16)
                divisor: int = int(divisor_hex, 16)
                if divisor != 0:
                    return (demand * multiplier) / divisor
    except Exception:
        pass
    return None

def send_command(ser: serial.Serial, cmd: str, response_tag: str, timeout: float = 3.0) -> Tuple[Optional[str], float]:
    """Sends a command to the EMU-2 and blocks until the matching response XML block is received.

    Args:
        ser: The opened serial.Serial connection object.
        cmd: The XML command string to send.
        response_tag: The expected root XML tag of the response (e.g. 'InstantaneousDemand').
        timeout: Maximum time in seconds to wait for response.

    Returns:
        A tuple of (response_xml_string or None, elapsed_time_in_seconds).
    """
    t_start: float = time.perf_counter()
    try:
        # Clear serial input buffer to avoid reading stale packets
        ser.reset_input_buffer()
        ser.write(cmd.encode('utf-8'))
        ser.flush()
    except Exception as e:
        print(f"Error writing command: {e}")
        return None, 0.0

    buffer: str = ""
    start_tag: str = f"<{response_tag}>"
    end_tag: str = f"</{response_tag}>"
    
    while (time.perf_counter() - t_start) < timeout:
        if ser.in_waiting > 0:
            data: bytes = ser.read(ser.in_waiting)
            buffer += data.decode('utf-8', errors='ignore')
            
            if start_tag in buffer and end_tag in buffer:
                idx_start: int = buffer.find(start_tag)
                idx_end: int = buffer.find(end_tag) + len(end_tag)
                elapsed: float = time.perf_counter() - t_start
                return buffer[idx_start:idx_end], elapsed
        time.sleep(0.01)
        
    return None, time.perf_counter() - t_start

def main() -> None:
    """Main execution loop for probing the EMU-2 serial interface."""
    port: str = '/dev/ttyACM0'
    print(f"Probing Rainforest EMU-2 on {port}...")
    
    try:
        ser: serial.Serial = serial.Serial(port, 115200, timeout=1, write_timeout=1)
    except Exception as e:
        print(f"Failed to open port {port}: {e}")
        sys.exit(1)
        
    cmd_demand: str = "<Command><Name>get_instantaneous_demand</Name></Command>\n"
    
    print("\nStarting 2-second active polling probe for 20 seconds (10 checks)...")
    print(f"{'Time':<12}{'RTT (ms)':<12}{'Demand (kW)':<15}{'Changed?'}")
    print("-" * 50)
    
    last_val: Optional[float] = None
    changes_count: int = 0
    total_rtt: float = 0.0
    valid_responses: int = 0
    
    for i in range(10):
        t_loop_start: float = time.perf_counter()
        resp_xml, rtt = send_command(ser, cmd_demand, 'InstantaneousDemand')
        
        timestamp: str = time.strftime('%H:%M:%S')
        
        if resp_xml:
            kw: Optional[float] = parse_instantaneous_demand(resp_xml)
            if kw is not None:
                rtt_ms: float = rtt * 1000.0
                total_rtt += rtt_ms
                valid_responses += 1
                
                changed: str = "No"
                if last_val is not None and abs(kw - last_val) > 1e-4:
                    changed = "YES"
                    changes_count += 1
                
                print(f"{timestamp:<12}{rtt_ms:<12.1f}{kw:<15.3f}{changed}")
                last_val = kw
            else:
                print(f"{timestamp:<12}{rtt*1000.0:<12.1f}{'Parse Error':<15}{'N/A'}")
        else:
            print(f"{timestamp:<12}{'Timeout':<12}{'No Response':<15}{'N/A'}")
            
        # Maintain a strict 2-second loop interval
        elapsed_loop: float = time.perf_counter() - t_loop_start
        sleep_time: float = max(0.0, 2.0 - elapsed_loop)
        time.sleep(sleep_time)
        
    ser.close()
    
    print("-" * 50)
    print("PROBE RESULTS SUMMARY:")
    if valid_responses > 0:
        avg_rtt: float = total_rtt / valid_responses
        print(f"Average Command RTT: {avg_rtt:.1f} ms")
        print(f"Total Updates Detected: {changes_count} out of {valid_responses} responses")
        approx_update_rate: float = (30 * 2.0) / max(1, changes_count) if changes_count > 0 else float('inf')
        print(f"Estimated Smart Meter Zigbee Refresh Period: {approx_update_rate:.1f} seconds")
    else:
        print("No valid responses received. Check hardware serial connection.")

if __name__ == '__main__':
    main()
