import tkinter as tk
import csv
import os
import json
import datetime
import sys
import textwrap
import matplotlib.dates as mdates
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.collections import LineCollection
from typing import List, Any

# Match settings from main dashboard.py
SUMMARY_FONT_SIZE: int = 11
SUMMARY_ALPHA: float = 0.55
SUMMARY_COLOR: str = 'deepskyblue'
IMPORT_COLOR: str = '#f43f5e'  # Modern rose red
EXPORT_COLOR: str = '#00ff00'  # Classic neon green

class OfflineViewer(tk.Tk):
    """Offline viewer that renders the historical grid telemetry for a screenshot."""

    def __init__(self) -> None:
        super().__init__()
        self.title("Grid Monitor Preview")
        self.configure(bg='black')
        
        # Configure windowed fullscreen/maximized size for easy screenshotting
        self.geometry("1024x768")
        
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<Button-1>", lambda e: self.destroy())

        self.usage: List[float] = []
        self.timestamps: List[datetime.datetime] = []
        self.se_power: List[float] = []
        self.se_timestamps: List[datetime.datetime] = []
        self.chilicon_power: List[float] = []
        self.chilicon_timestamps: List[datetime.datetime] = []
        self.chilicon_off: bool = "--chiliconoff" in sys.argv
        
        # Load local history file copied from the Pi
        self.load_history()
        self.load_solaredge_history()
        self.load_chilicon_history()

        # UI Text label configuration
        latest_val = self.usage[-1] if self.usage else 0.0
        status = "Combined Solar Export (PV)" if latest_val < 0 else "Importing (Grid)"
        color = EXPORT_COLOR if latest_val < 0 else IMPORT_COLOR
        text = f"{latest_val:.3f} kW | {status}"

        self.status_label: tk.Label = tk.Label(
            self, text=text, font=('Helvetica', 36, 'bold'), bg='black', fg=color
        )
        self.status_label.pack(pady=5)

        latest_pv = self.se_power[-1] if self.se_power else 0.0
        self.sub_status_label: tk.Label = tk.Label(
            self, text=f"SolarEdge PV: {latest_pv:.3f} kW", font=('Helvetica', 20, 'bold'), bg='black', fg='#fbbf24'
        )
        self.sub_status_label.pack(pady=2)

        self.chilicon_status_label: tk.Label = tk.Label(
            self, text="", font=('Helvetica', 20, 'bold'), bg='black', fg='#ffff00'
        )
        if not self.chilicon_off:
            self.chilicon_status_label.pack(pady=2)
            latest_ch = self.chilicon_power[-1] if self.chilicon_power else 0.0
            self.chilicon_status_label.config(text=f"Chillicon PV: {latest_ch:.3f} kW")

        # Matplotlib figure setup
        self.fig: Figure = Figure(figsize=(5, 3), dpi=100, facecolor='black')
        self.fig.subplots_adjust(left=0.15, right=0.95, top=0.95, bottom=0.15)
        
        self.ax: Any = self.fig.add_subplot(111)
        self.ax.set_facecolor('black')
        self.ax.tick_params(colors='white')
        self.ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        self.fig.autofmt_xdate()
        self.ax.spines['bottom'].set_color('white')
        self.ax.spines['left'].set_color('white')
        # Secondary axes for SolarEdge bar chart along the bottom
        self.ax_bar = self.ax.twinx()
        self.ax_bar.set_ylim(0, 10)  # Fixed arbitrary high limit so bars stay at bottom
        self.ax_bar.tick_params(colors='#fbbf24')
        self.ax_bar.yaxis.set_label_position('right')
        self.ax_bar.spines['right'].set_color('#fbbf24')
        self.ax_bar.spines['left'].set_color('none')
        self.ax_bar.spines['top'].set_color('none')
        self.ax_bar.spines['bottom'].set_color('none')
        self.ax_bar.set_ylabel('SolarEdge PV (kW)', color='#fbbf24', rotation=270, labelpad=15)
        
        # Swap z-order so the main ax (and its overlay text/line plot) sits on top of ax_bar
        self.ax.set_zorder(self.ax_bar.get_zorder() + 1)
        self.ax.patch.set_visible(False)  # Must be transparent so ax_bar behind it is visible
        
        # Dotted horizontal line at 0 kW
        self.ax.axhline(0, color='gray', linestyle='--') 
        
        # LineCollection for dynamic segment styling
        self.lc: LineCollection = LineCollection([], linewidths=1.8, zorder=3)
        self.ax.add_collection(self.lc)
        
        # Background summary text watermark
        self.summary_text_obj: Any = self.ax.text(
            0.02, 0.95, "",
            transform=self.ax.transAxes,
            ha='left', va='top',
            fontsize=SUMMARY_FONT_SIZE,
            color=SUMMARY_COLOR,
            alpha=SUMMARY_ALPHA,
            fontfamily='monospace',
            weight='bold',
            zorder=10
        )
        
        self.canvas: FigureCanvasTkAgg = FigureCanvasTkAgg(self.fig, master=self)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # Load cached summary and draw the plot
        self.load_cached_summary()
        self.update_chart()

        # Schedule automatic screenshot generation after window loads
        self.after(1500, self.save_screenshot)

    def load_history(self) -> None:
        """Loads data from local grid_history.csv file."""
        history_file = 'grid_history.csv'
        if not os.path.exists(history_file):
            print("Error: grid_history.csv not found in local directory!")
            return
            
        print("Loading local history...")
        # Get the latest timestamp in the file to establish the 24-hour cutoff
        last_ts = None
        try:
            with open(history_file, 'r') as f:
                reader = csv.reader(f)
                rows = list(reader)
                if rows:
                    for row in reversed(rows):
                        if len(row) == 2:
                            try:
                                last_ts = datetime.datetime.fromisoformat(row[0].strip())
                                break
                            except ValueError:
                                continue
        except Exception as e:
            print(f"Failed to pre-scan history file: {e}")
            return

        if not last_ts:
            print("No valid timestamps found in history.")
            return

        cutoff = last_ts - datetime.timedelta(days=1)
        
        try:
            with open(history_file, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) == 2:
                        try:
                            ts_str = row[0].replace('\x00', '').strip()
                            val_str = row[1].replace('\x00', '').strip()
                            if not ts_str or not val_str:
                                continue
                            ts = datetime.datetime.fromisoformat(ts_str)
                            if ts > cutoff:
                                self.timestamps.append(ts)
                                self.usage.append(float(val_str))
                        except Exception:
                            continue
            print(f"Loaded {len(self.usage)} data points.")
        except Exception as e:
            print(f"Failed to read history file: {e}")

    def load_solaredge_history(self) -> None:
        """Loads SolarEdge historical telemetry from CSV file."""
        se_history_file = 'solaredge_history.csv'
        if not os.path.exists(se_history_file):
            print("Warning: solaredge_history.csv not found.")
            return
            
        print("Loading local SolarEdge history...")
        # Align with the same 24-hour cutoff as the main history file
        if self.timestamps:
            cutoff = self.timestamps[-1] - datetime.timedelta(days=1)
        else:
            cutoff = datetime.datetime.now() - datetime.timedelta(days=1)
            
        try:
            with open(se_history_file, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) == 2:
                        try:
                            ts_str = row[0].strip().replace('\x00', '')
                            val_str = row[1].strip().replace('\x00', '')
                            if not ts_str or not val_str:
                                continue
                            ts = datetime.datetime.fromisoformat(ts_str)
                            if ts > cutoff:
                                self.se_timestamps.append(ts)
                                self.se_power.append(float(val_str))
                        except Exception:
                            continue
            print(f"Loaded {len(self.se_power)} SolarEdge historical data points.")
        except Exception as e:
            print(f"Failed to read SolarEdge history file: {e}")

    def load_chilicon_history(self) -> None:
        """Loads Chillicon historical telemetry from CSV file."""
        if self.chilicon_off:
            return
        chilicon_history_file = 'chilicon_history.csv'
        if not os.path.exists(chilicon_history_file):
            print("Warning: chilicon_history.csv not found.")
            return
            
        print("Loading local Chillicon history...")
        if self.timestamps:
            cutoff = self.timestamps[-1] - datetime.timedelta(days=1)
        else:
            cutoff = datetime.datetime.now() - datetime.timedelta(days=1)
            
        try:
            with open(chilicon_history_file, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) == 3:
                        try:
                           ts_str = row[0].strip().replace('\x00', '')
                           val_str = row[1].strip().replace('\x00', '')
                           if not ts_str or not val_str:
                               continue
                           ts = datetime.datetime.fromisoformat(ts_str)
                           if ts > cutoff:
                               self.chilicon_timestamps.append(ts)
                               self.chilicon_power.append(float(val_str))
                        except Exception:
                           continue
            print(f"Loaded {len(self.chilicon_power)} Chillicon historical data points.")
        except Exception as e:
            print(f"Failed to read Chillicon history file: {e}")

    def load_cached_summary(self) -> None:
        """Loads local gemini_summary.json and sets the watermark."""
        cache_file = 'gemini_summary.json'
        if not os.path.exists(cache_file):
            print("No local gemini_summary.json found.")
            return
            
        try:
            with open(cache_file, 'r') as f:
                data = json.load(f)
                summary = data.get("summary")
                if summary:
                    self.summary_text_obj.set_text(self.wrap_text(summary.strip()))
                    print("Loaded cached Gemini summary.")
        except Exception as e:
            print(f"Failed to load cache: {e}")

    def wrap_text(self, text: str, width: int = 80) -> str:
        paragraphs = text.split('\n\n')
        wrapped_paragraphs = []
        for para in paragraphs:
            lines = para.split('\n')
            is_structured = False
            for line in lines:
                stripped = line.strip()
                if stripped.startswith(('*', '-', '1.', '2.', '3.')) or '   ' in line or '\t' in line:
                    is_structured = True
                    break
                    
            if is_structured:
                wrapped_lines = []
                for line in lines:
                    if len(line) <= width:
                        wrapped_lines.append(line)
                    else:
                        initial_indent = len(line) - len(line.lstrip())
                        indent_str = " " * initial_indent
                        wrapped_lines.append(textwrap.fill(
                            line,
                            width=width,
                            initial_indent=indent_str,
                            subsequent_indent=indent_str + "  "
                        ))
                wrapped_paragraphs.append('\n'.join(wrapped_lines))
            else:
                wrapped_paragraphs.append(textwrap.fill(para, width=width))
                
        return '\n\n'.join(wrapped_paragraphs)

    def update_chart(self) -> None:
        """Draws the dynamic line plot and scales the axes."""
        if len(self.usage) > 1:
            x_nums = mdates.date2num(self.timestamps)
            segments = []
            colors = []
            widths = []
            for i in range(len(self.usage) - 1):
                y1, y2 = self.usage[i], self.usage[i+1]
                segments.append(((x_nums[i], y1), (x_nums[i+1], y2)))
                avg_y = (y1 + y2) / 2.0
                if avg_y > 0:
                    colors.append(IMPORT_COLOR)
                    widths.append(1.8)
                else:
                    colors.append(EXPORT_COLOR)
                    widths.append(1.3)
            self.lc.set_segments(segments)
            self.lc.set_colors(colors)
            self.lc.set_linewidths(widths)
            
            # Draw the bar chart on the twin axes using stacked SolarEdge and Chillicon data
            self.ax_bar.clear()
            self.ax_bar.tick_params(colors='#fbbf24')
            self.ax_bar.yaxis.set_label_position('right')
            self.ax_bar.spines['right'].set_color('#fbbf24')
            self.ax_bar.spines['left'].set_color('none')
            self.ax_bar.spines['top'].set_color('none')
            self.ax_bar.spines['bottom'].set_color('none')
            self.ax_bar.set_ylabel('Total Solar PV (kW)', color='#fbbf24', rotation=270, labelpad=15)
            
            end_time = self.timestamps[-1] if self.timestamps else datetime.datetime.now()
            start_time = end_time - datetime.timedelta(hours=24)
            
            # Align both SolarEdge and Chillicon on a regular, forward-filled 10-minute grid
            bar_times = []
            se_heights = []
            ch_heights = []
            
            # Start at start_time rounded down to the nearest 10-minute slot
            grid_start = start_time.replace(minute=(start_time.minute // 10) * 10, second=0, microsecond=0)
            current_slot = grid_start
            
            while current_slot <= end_time:
                bar_times.append(current_slot)
                
                # Find most recent SolarEdge power value <= current_slot and within 30 minutes
                se_val = 0.0
                for ts, p in zip(self.se_timestamps, self.se_power):
                    if ts <= current_slot and current_slot - ts <= datetime.timedelta(minutes=30):
                        se_val = p
                se_heights.append(se_val)
                
                # Find most recent Chillicon power value <= current_slot and within 30 minutes
                ch_val = 0.0
                if not self.chilicon_off:
                    for ts, p in zip(self.chilicon_timestamps, self.chilicon_power):
                        if ts <= current_slot and current_slot - ts <= datetime.timedelta(minutes=30):
                            ch_val = p
                ch_heights.append(ch_val)
                
                current_slot += datetime.timedelta(minutes=10)
            
            if bar_times:
                width_in_days = 10.0 / (24.0 * 60.0) # 10 minutes
                # Draw SolarEdge (bottom)
                self.ax_bar.bar(bar_times, se_heights, width=width_in_days, color='#fbbf24', alpha=0.1, zorder=1, edgecolor='none')
                # Draw Chillicon (stacked on top of SolarEdge - bright neon yellow)
                self.ax_bar.bar(bar_times, ch_heights, bottom=se_heights, width=width_in_days, color='#ffff00', alpha=0.15, zorder=1.5, edgecolor='none')
                
                max_power = max([s + c for s, c in zip(se_heights, ch_heights)]) if bar_times else 1.0
                self.ax_bar.set_ylim(0, max_power * 3)
            else:
                self.ax_bar.set_ylim(0, 10)
        
        if self.timestamps:
            # Match the rolling 24-hour window ending at the last data point
            end_time = self.timestamps[-1]
            start_time = end_time - datetime.timedelta(hours=24)
            self.ax.set_xlim(start_time, end_time)
        
        if self.usage:
            y_min = min(self.usage)
            y_max = max(self.usage)
            padding = max(abs(y_max - y_min) * 0.2, 0.5)
            self.ax.set_ylim(min(0, y_min - padding), max(0, y_max + padding))
            
        self.fig.canvas.draw()

    def save_screenshot(self) -> None:
        """Programmatically captures the TK window and saves it to dashboard_preview.jpeg."""
        self.attributes('-topmost', True)
        self.lift()
        self.focus_force()
        self.update()
        
        # Give the OS window manager a brief moment to bring the window to the front
        import time
        time.sleep(0.5)
        
        # Retrieve coordinates relative to the screen
        x = self.winfo_rootx()
        y = self.winfo_rooty()
        w = self.winfo_width()
        h = self.winfo_height()
        
        import platform
        import subprocess
        
        if platform.system() == "Darwin":
            try:
                # Use macOS's built-in screencapture tool which handles Retina scaling and coordinates cleanly.
                # Format: screencapture -o -t jpg -R x,y,w,h output.jpeg
                cmd = ["screencapture", "-o", "-t", "jpg", "-R", f"{x},{y},{w},{h}", "dashboard_preview.jpeg"]
                subprocess.run(cmd, check=True)
                print("Successfully captured and saved dashboard_preview.jpeg via macOS screencapture!")
            except Exception as e:
                print(f"macOS screencapture failed: {e}. Trying PIL fallback...")
                self._pil_fallback(x, y, w, h)
        else:
            self._pil_fallback(x, y, w, h)

    def _pil_fallback(self, x: int, y: int, w: int, h: int) -> None:
        from PIL import ImageGrab
        try:
            img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
            img.convert('RGB').save('dashboard_preview.jpeg', 'JPEG', quality=95)
            print("Successfully captured and saved dashboard_preview.jpeg via PIL ImageGrab!")
        except Exception as e:
            print(f"Error capturing screenshot via PIL: {e}")

if __name__ == "__main__":
    app = OfflineViewer()
    app.mainloop()
